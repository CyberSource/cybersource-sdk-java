package com.cybersource.sample;



import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class RunSampleParallel {
    public static AtomicInteger txnTPS = new AtomicInteger(0);
    public static AtomicInteger totalSuccessfulTxn = new AtomicInteger(0);
    public static AtomicInteger totalTxnSent = new AtomicInteger(0);
    public static ExecutorService executorService;
    public static int tps;
    public static void main(String[] args) {
        System.out.println("Start time >> "+ LocalDateTime.now().toString());
        tps = Integer.parseInt(args[0]);
        registerShutdownHook();
        System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.SimpleLog");
        System.setProperty("org.apache.commons.logging.simplelog.showdatetime", "true");
        System.setProperty("org.apache.commons.logging.simplelog.log.httpclient.wire", "debug");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http", "debug");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.headers", "debug");
        executorService = Executors.newFixedThreadPool(100);
        String argument="cybs";
        Properties props = RunSample.readProperty(argument + ".properties");

        TPSCalculator tpsCalculator = new TPSCalculator();
        Thread t = new Thread(tpsCalculator);
        t.start();

        while (true) {
                executeTask(props, executorService);
        }

    }

    private static void registerShutdownHook() {
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                System.out.println("Shutdown hook triggered.");
                try {
                    Thread.sleep(15000);
                    System.out.println("=====================================================");
                    System.out.println("Total transaction executed >> " + totalTxnSent);
                    System.out.println("Total transaction successfully executed >> " + totalSuccessfulTxn);
                    System.out.println("=====================================================");
                    System.out.println("End time >> "+ LocalDateTime.now().toString());

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    executorService.shutdown();
                }

            }
        });
    }

    private static void executeTask(Properties props, ExecutorService executorService) {
        List<Callable<String>> tasks = new ArrayList<Callable<String>>();

        for (int i = 0; i < RunSampleParallel.tps; i++) {
            RunCallable trans = new RunCallable(props);
            tasks.add(trans);
        }

        List<Future<String>> results = null;

        try {
            results = executorService.invokeAll(tasks);
            try {

                for (Future future : results) {
                    System.out.println("Request id : " + future.get());
                    txnTPS.incrementAndGet();
                    totalSuccessfulTxn.incrementAndGet();
                }

            } catch (ExecutionException e) {
                e.printStackTrace();
            }

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class RunCallable implements Callable {

    private final Properties cybsProperties;

    RunCallable(Properties cybsProperties) {
        this.cybsProperties = cybsProperties;
    }
    @Override
    public Object call() throws Exception {
        RunSampleParallel.totalTxnSent.incrementAndGet();
        return RunSample.runAuth(cybsProperties);
    }
}

class TPSCalculator implements Runnable {

    public boolean shutdown;
    @Override
    public void run() {
        while(!shutdown) {
            System.out.println("Current TPS >>> " + RunSampleParallel.txnTPS.get() / 60);
            RunSampleParallel.txnTPS.set(0);
            try {
                Thread.sleep(60000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}