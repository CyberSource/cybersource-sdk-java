# CyberSource SCMP Client for Java

This repository contains the Java implementation of the Simple Commerce Message Protocol (SCMP) client for CyberSource payment processing services.

## Introduction

The SCMP Client for Java provides a Java interface to CyberSource's payment processing services using the Simple Commerce Message Protocol. It allows merchants to process various types of payment transactions including:

- Credit card authorizations and captures
- Electronic check processing
- Tax calculations
- Risk management services
- And more

This client handles the communication, encryption, authentication, and message formatting required to interact with CyberSource's services.

## Prerequisites

- **Java**: JDK 1.8 or higher
- **Merchant Account**: A CyberSource merchant account
- **Certificates**: Valid merchant certificates for authentication

## Installation

1. Extract the distribution package (`icsdist-[version].zip`)
2. Add the JAR files to your project's classpath

## Configuration

The client is configured using a properties file. A template is provided at `icsdist/src/main/config/properties/ICSClient.props.template`.

1. Copy the template to create your configuration file:
   ```
   cp ICSClient.props.template ICSClient.props
   ```

2. Edit the properties file with your specific settings:

   ```properties
   # Your merchant ID
   merchantID=your_merchant_id
   
   # URL of the server (test or production)
   serverURL=https://ics2test.ic3.com:443/
   
   # Use JDK URL Connection (recommended)
   useJdkUrlConnection=true
   
   # Directory containing certificate and private key files
   ics.keysPath=/path/to/your/keys
   
   # Debug settings
   debugLevel=0
   debugFile=debug.log
   
   # SSL properties (if needed)
   #ssl.trustAllHostNames=false
   #ssl.keyStore=/path/to/keystore.jks
   #ssl.keyStorePassword=password
   #ssl.trustStore=/path/to/truststore.jks
   #ssl.trustStorePassword=password
   ```

### Proxy Configuration

If you need to use a proxy server:

```properties
# HTTPS proxy settings
https.proxyHost=proxy.example.com
https.proxyPort=8080
```

## Certificates

The client requires certificates for secure communication with CyberSource servers.

### Required Certificate Files

1. **Your Private Key** (`your_merchant_id.pvt`): Your private key file
2. **Your Certificate** (`your_merchant_id.crt`): Your merchant certificate
3. **CyberSource Certificate** (`CyberSource_SJC_US.crt`): CyberSource's server certificate

### Certificate Setup

1. Place your certificate files in the directory specified by `ics.keysPath` in your properties file
2. Ensure the files are named correctly according to your merchant ID
3. Alternatively, specify the full paths to each certificate file:

   ```properties
   myPrivateKey=/path/to/your_merchant_id.pvt
   myCert=/path/to/your_merchant_id.crt
   serverCert=/path/to/CyberSource_SJC_US.crt
   ```

### SSL Configuration

For additional SSL configuration:

```properties
ssl.keyStore=/path/to/keystore.jks
ssl.keyStorePassword=password
ssl.trustStore=/path/to/truststore.jks
ssl.trustStorePassword=password
```

## Available Services

The client supports various CyberSource services, including:

- `ics_auth`: Credit card authorization
- `ics_bill`: Credit card billing/capture
- `ics_credit`: Credit card refund
- `ics_tax`: Tax calculation
- `ics_score`: Risk management
- `ics_ecp_debit`: Electronic check debit
- `ics_ecp_credit`: Electronic check credit
- `ics_export`: Export compliance service

Multiple services can be requested in a single transaction by comma-separating the service names in the `ics_applications` field.

### Available Test Files

The distribution includes several test files that demonstrate different services. For details refer to README_TEST.txt.


## Troubleshooting

### Common Issues

1. **Connection Problems**
   - Verify your network connection
   - Check proxy settings if applicable
   - Ensure the server URL is correct

2. **Certificate Issues**
   - Verify certificate paths are correct
   - Check certificate expiration dates
   - Ensure private key matches the certificate

3. **Authentication Failures**
   - Verify your merchant ID is correct
   - Check that your certificate is properly registered with CyberSource

### Debugging

Enable debug logging by setting the following properties:

```properties
debugLevel=5  # 0 (none) to 5 (maximum)
debugFile=debug.log
```

## Further Information

### Merchant ID

To use this SDK, you must be a registered merchant. If you have
not already obtained a merchant ID from CyberSource, go to
http://www.cybersource.com/register and register for a test account.

The ICS merchant_id field uniquely identifies you to CyberSource and
is not related in any way to the merchant ID assigned to you by a
payment processor. To use your encryption key and certificate to send
transactions to the CyberSource ICS test or production servers, you
must provide your CyberSource merchant ID in each transaction.

### Generating Private Key and Certificate

To generate your private key and certificate to use for sending test
and live transactions to the ICS2 server, logon to EBC and
choose the Generate Keys option. Download the files to the keys
directory specified by the ics.keysPath setting.

### Prepare to Send Live Transactions

To go live, verify that you have done the following:

- Changed the ICSClient.props file in the properties directory to
  match your merchant ID, certificate, and private key. Keep in mind
  that merchant ID is your merchant ID with CyberSource, and it is not
  related to any payment processor merchant ID. This is the ID
  assigned to you by CyberSource. You use it to generate your key
  pairs.

- Successfully tested your application against the ICS2 test server at
  the following URL:

  http://ics2test.ic3.com/

- Changed the ICSClient.props file to match the URL of the production
  server:

  http://ics2.ic3.com/

